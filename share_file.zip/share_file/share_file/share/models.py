from django.db import models
import random
import string
from django.utils import timezone
from datetime import timedelta

def generate_search_code():
    return ''.join(random.choices(string.digits, k=4))

class SharedFile(models.Model):
    file = models.FileField(upload_to='uploads/')
    search_code = models.CharField(default=generate_search_code, max_length=4, unique=True)
    created_at = models.DateTimeField(default=timezone.now)

    def is_expired(self):
        return self.created_at + timedelta(minutes=1) < timezone.now()

class SharedText(models.Model):
    text_content = models.TextField()
    search_code = models.CharField(default=generate_search_code, max_length=4, unique=True)
