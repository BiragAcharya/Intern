from django.contrib import admin
from .models import SharedFile

# Register your models here.
admin.site.register(SharedFile)