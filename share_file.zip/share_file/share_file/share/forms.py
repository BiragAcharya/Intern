
from django import forms
from .models import SharedFile, SharedText

class SharedFileForm(forms.ModelForm):
    class Meta:
        model = SharedFile
        fields = ['file']

class SharedTextForm(forms.ModelForm):
    class Meta:
        model = SharedText
        fields = ['text_content']