# from django.shortcuts import render, redirect, get_object_or_404
# from django.utils import timezone
# from django.http import HttpResponse, Http404
# from .models import SharedFile, SharedText
# from .forms import SharedFileForm, SharedTextForm

# def upload_file(request):
#     if request.method == 'POST':
#         form = SharedFileForm(request.POST, request.FILES)
#         if form.is_valid():
#             shared_file = form.save()
#             return render(request, 'uploaded_file.html', {'shared_file': shared_file})
#     else:
#         form = SharedFileForm()
#     return render(request, 'upload_file.html', {'form': form})

# def share_text(request):
#     if request.method == 'POST':
#         form = SharedTextForm(request.POST)
#         if form.is_valid():
#             shared_text = form.save()
#             return render(request, 'shared_text.html', {'shared_text': shared_text})
#     else:
#         form = SharedTextForm()
#     return render(request, 'share_text.html', {'form': form})

# def retrieve_content(request):
#     if request.method == 'POST':
#         retrieval_code = request.POST.get('retrieval_code')
#         print(f"The retrieval code inputted by the user is: {retrieval_code}")  # for debugging purposes

#         if not retrieval_code:
#             return render(request, 'not_found.html')  # Handle empty retrieval code

#         # Try to get the file
#         shared_file = SharedFile.objects.filter(retrieval_code=retrieval_code).first()
#         print(f"Shared file is: {shared_file}")
#         if shared_file:
#             if shared_file.is_expired():
#                 shared_file.file.delete()  # Delete file from storage
#                 shared_file.delete()       # Delete record from database
#                 return render(request, 'expires.html')
#             return render(request, 'retrieved_file.html', {'shared_file': shared_file})

#         # Try to get the text
#         shared_text = SharedText.objects.filter(retrieval_code=retrieval_code).first()
#         print(f"Shared text is: {shared_text}")
#         if shared_text:
#             return render(request, 'retrieved_text.html', {'shared_text': shared_text})

#         return render(request, 'not_found.html')  # Render a not found template if no content is found

#     return render(request, 'retrieve_content.html')

# def home(request):
#     return render(request, 'home.html')

# def download_file(request, file_id):
#     shared_file = get_object_or_404(SharedFile, id=file_id)
#     file_path = shared_file.file.path
#     file_name = shared_file.file.name.split('/')[-1]

#     try:
#         with open(file_path, 'rb') as file:
#             response = HttpResponse(file.read(), content_type='application/octet-stream')
#             response['Content-Disposition'] = f'attachment; filename="{file_name}"'
#             return response
#     except FileNotFoundError:
#         raise Http404("File not found")

# def download_text(request, retrieval_code):
#     try:
#         shared_text = SharedText.objects.get(retrieval_code=retrieval_code)
#         response = HttpResponse(shared_text.text_content, content_type='text/plain')
#         response['Content-Disposition'] = f'attachment; filename="{retrieval_code}.txt"'
#         return response
#     except SharedText.DoesNotExist:
#         return render(request, 'not_found.html', status=404)


from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.http import HttpResponse, Http404
from .models import SharedFile, SharedText
from .forms import SharedFileForm, SharedTextForm

def upload_file(request):
    if request.method == 'POST':
        form = SharedFileForm(request.POST, request.FILES)
        if form.is_valid():
            shared_file = form.save()
            return render(request, 'uploaded_file.html', {'shared_file': shared_file})
    else:
        form = SharedFileForm()
    return render(request, 'upload_file.html', {'form': form})

def share_text(request):
    if request.method == 'POST':
        form = SharedTextForm(request.POST)
        if form.is_valid():
            shared_text = form.save()
            return render(request, 'shared_text.html', {'shared_text': shared_text})
    else:
        form = SharedTextForm()
    return render(request, 'share_text.html', {'form': form})

def search_content(request):
    if request.method == 'POST':
        search_code = request.POST.get('search_code')
        print(f"The search code inputted by the user is: {search_code}")

        if not search_code:
            return render(request, 'not_found.html')

        shared_file = SharedFile.objects.filter(search_code=search_code).first()
        print(f"Shared file is: {shared_file}")
        if shared_file:
            if shared_file.is_expired():
                shared_file.file.delete()
                shared_file.delete()
                return render(request, 'expires.html')
            return render(request, 'searched_file.html', {'shared_file': shared_file})

        shared_text = SharedText.objects.filter(search_code=search_code).first()
        print(f"Shared text is: {shared_text}")
        if shared_text:
            return render(request, 'searched_text.html', {'shared_text': shared_text})

        return render(request, 'not_found.html')

    return render(request, 'search_content.html')

def home(request):
    return render(request, 'home.html')

def download_file(request, file_id):
    shared_file = get_object_or_404(SharedFile, id=file_id)
    file_path = shared_file.file.path
    file_name = shared_file.file.name.split('/')[-1]

    try:
        with open(file_path, 'rb') as file:
            response = HttpResponse(file.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
    except FileNotFoundError:
        raise Http404("File not found")

def download_text(request, search_code):
    try:
        shared_text = SharedText.objects.get(search_code=search_code)
        response = HttpResponse(shared_text.text_content, content_type='text/plain')
        response['Content-Disposition'] = f'attachment; filename="{search_code}.txt"'
        return response
    except SharedText.DoesNotExist:
        return render(request, 'not_found.html', status=404)
