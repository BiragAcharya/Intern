# from django.contrib import admin
# from django.urls import path
# from django.conf import settings
# from django.conf.urls.static import static
# from file_sharing import views

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('', views.home, name='home'),
#     path('upload-file/', views.upload_file, name='upload_file'),
#     path('share-text/', views.share_text, name='share_text'),
#     path('retrieve-content/', views.retrieve_content, name='retrieve_content'),
#     path('download/<int:file_id>/', views.download_file, name='download_file'),
#     # path('download-text/<str:retrieval_code>/', views.download_text, name='download_text'), 
#      path('download-text/<str:retrieval_code>/', views.download_text, name='download_text'),  
# ]

# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from share import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('upload-file/', views.upload_file, name='upload_file'),
    path('share-text/', views.share_text, name='share_text'),
    path('search-content/', views.search_content, name='search_content'),
    path('download/<int:file_id>/', views.download_file, name='download_file'),
    path('download-text/<str:search_code>/', views.download_text, name='download_text'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
